/*******************************************************************************
* File Name: Display_Refresh_Timer_PM.c
* Version 2.70
*
*  Description:
*     This file provides the power management source code to API for the
*     Timer.
*
*   Note:
*     None
*
*******************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/

#include "Display_Refresh_Timer.h"

static Display_Refresh_Timer_backupStruct Display_Refresh_Timer_backup;


/*******************************************************************************
* Function Name: Display_Refresh_Timer_SaveConfig
********************************************************************************
*
* Summary:
*     Save the current user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Display_Refresh_Timer_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void Display_Refresh_Timer_SaveConfig(void) 
{
    #if (!Display_Refresh_Timer_UsingFixedFunction)
        Display_Refresh_Timer_backup.TimerUdb = Display_Refresh_Timer_ReadCounter();
        Display_Refresh_Timer_backup.InterruptMaskValue = Display_Refresh_Timer_STATUS_MASK;
        #if (Display_Refresh_Timer_UsingHWCaptureCounter)
            Display_Refresh_Timer_backup.TimerCaptureCounter = Display_Refresh_Timer_ReadCaptureCount();
        #endif /* Back Up capture counter register  */

        #if(!Display_Refresh_Timer_UDB_CONTROL_REG_REMOVED)
            Display_Refresh_Timer_backup.TimerControlRegister = Display_Refresh_Timer_ReadControlRegister();
        #endif /* Backup the enable state of the Timer component */
    #endif /* Backup non retention registers in UDB implementation. All fixed function registers are retention */
}


/*******************************************************************************
* Function Name: Display_Refresh_Timer_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Display_Refresh_Timer_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void Display_Refresh_Timer_RestoreConfig(void) 
{   
    #if (!Display_Refresh_Timer_UsingFixedFunction)

        Display_Refresh_Timer_WriteCounter(Display_Refresh_Timer_backup.TimerUdb);
        Display_Refresh_Timer_STATUS_MASK =Display_Refresh_Timer_backup.InterruptMaskValue;
        #if (Display_Refresh_Timer_UsingHWCaptureCounter)
            Display_Refresh_Timer_SetCaptureCount(Display_Refresh_Timer_backup.TimerCaptureCounter);
        #endif /* Restore Capture counter register*/

        #if(!Display_Refresh_Timer_UDB_CONTROL_REG_REMOVED)
            Display_Refresh_Timer_WriteControlRegister(Display_Refresh_Timer_backup.TimerControlRegister);
        #endif /* Restore the enable state of the Timer component */
    #endif /* Restore non retention registers in the UDB implementation only */
}


/*******************************************************************************
* Function Name: Display_Refresh_Timer_Sleep
********************************************************************************
*
* Summary:
*     Stop and Save the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Display_Refresh_Timer_backup.TimerEnableState:  Is modified depending on the
*  enable state of the block before entering sleep mode.
*
*******************************************************************************/
void Display_Refresh_Timer_Sleep(void) 
{
    #if(!Display_Refresh_Timer_UDB_CONTROL_REG_REMOVED)
        /* Save Counter's enable state */
        if(Display_Refresh_Timer_CTRL_ENABLE == (Display_Refresh_Timer_CONTROL & Display_Refresh_Timer_CTRL_ENABLE))
        {
            /* Timer is enabled */
            Display_Refresh_Timer_backup.TimerEnableState = 1u;
        }
        else
        {
            /* Timer is disabled */
            Display_Refresh_Timer_backup.TimerEnableState = 0u;
        }
    #endif /* Back up enable state from the Timer control register */
    Display_Refresh_Timer_Stop();
    Display_Refresh_Timer_SaveConfig();
}


/*******************************************************************************
* Function Name: Display_Refresh_Timer_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Display_Refresh_Timer_backup.enableState:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void Display_Refresh_Timer_Wakeup(void) 
{
    Display_Refresh_Timer_RestoreConfig();
    #if(!Display_Refresh_Timer_UDB_CONTROL_REG_REMOVED)
        if(Display_Refresh_Timer_backup.TimerEnableState == 1u)
        {     /* Enable Timer's operation */
                Display_Refresh_Timer_Enable();
        } /* Do nothing if Timer was disabled before */
    #endif /* Remove this code section if Control register is removed */
}


/* [] END OF FILE */
