/*******************************************************************************
* File Name: XB_Location_Broadcast.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_XB_Location_Broadcast_H)
#define CY_ISR_XB_Location_Broadcast_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void XB_Location_Broadcast_Start(void);
void XB_Location_Broadcast_StartEx(cyisraddress address);
void XB_Location_Broadcast_Stop(void);

CY_ISR_PROTO(XB_Location_Broadcast_Interrupt);

void XB_Location_Broadcast_SetVector(cyisraddress address);
cyisraddress XB_Location_Broadcast_GetVector(void);

void XB_Location_Broadcast_SetPriority(uint8 priority);
uint8 XB_Location_Broadcast_GetPriority(void);

void XB_Location_Broadcast_Enable(void);
uint8 XB_Location_Broadcast_GetState(void);
void XB_Location_Broadcast_Disable(void);

void XB_Location_Broadcast_SetPending(void);
void XB_Location_Broadcast_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the XB_Location_Broadcast ISR. */
#define XB_Location_Broadcast_INTC_VECTOR            ((reg32 *) XB_Location_Broadcast__INTC_VECT)

/* Address of the XB_Location_Broadcast ISR priority. */
#define XB_Location_Broadcast_INTC_PRIOR             ((reg8 *) XB_Location_Broadcast__INTC_PRIOR_REG)

/* Priority of the XB_Location_Broadcast interrupt. */
#define XB_Location_Broadcast_INTC_PRIOR_NUMBER      XB_Location_Broadcast__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable XB_Location_Broadcast interrupt. */
#define XB_Location_Broadcast_INTC_SET_EN            ((reg32 *) XB_Location_Broadcast__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the XB_Location_Broadcast interrupt. */
#define XB_Location_Broadcast_INTC_CLR_EN            ((reg32 *) XB_Location_Broadcast__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the XB_Location_Broadcast interrupt state to pending. */
#define XB_Location_Broadcast_INTC_SET_PD            ((reg32 *) XB_Location_Broadcast__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the XB_Location_Broadcast interrupt. */
#define XB_Location_Broadcast_INTC_CLR_PD            ((reg32 *) XB_Location_Broadcast__INTC_CLR_PD_REG)


#endif /* CY_ISR_XB_Location_Broadcast_H */


/* [] END OF FILE */
