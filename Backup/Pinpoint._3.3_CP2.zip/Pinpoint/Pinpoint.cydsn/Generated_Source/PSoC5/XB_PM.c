/*******************************************************************************
* File Name: XB_PM.c
* Version 2.50
*
* Description:
*  This file provides Sleep/WakeUp APIs functionality.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "XB.h"


/***************************************
* Local data allocation
***************************************/

static XB_BACKUP_STRUCT  XB_backup =
{
    /* enableState - disabled */
    0u,
};



/*******************************************************************************
* Function Name: XB_SaveConfig
********************************************************************************
*
* Summary:
*  This function saves the component nonretention control register.
*  Does not save the FIFO which is a set of nonretention registers.
*  This function is called by the XB_Sleep() function.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  XB_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void XB_SaveConfig(void)
{
    #if(XB_CONTROL_REG_REMOVED == 0u)
        XB_backup.cr = XB_CONTROL_REG;
    #endif /* End XB_CONTROL_REG_REMOVED */
}


/*******************************************************************************
* Function Name: XB_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the nonretention control register except FIFO.
*  Does not restore the FIFO which is a set of nonretention registers.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  XB_backup - used when non-retention registers are restored.
*
* Reentrant:
*  No.
*
* Notes:
*  If this function is called without calling XB_SaveConfig() 
*  first, the data loaded may be incorrect.
*
*******************************************************************************/
void XB_RestoreConfig(void)
{
    #if(XB_CONTROL_REG_REMOVED == 0u)
        XB_CONTROL_REG = XB_backup.cr;
    #endif /* End XB_CONTROL_REG_REMOVED */
}


/*******************************************************************************
* Function Name: XB_Sleep
********************************************************************************
*
* Summary:
*  This is the preferred API to prepare the component for sleep. 
*  The XB_Sleep() API saves the current component state. Then it
*  calls the XB_Stop() function and calls 
*  XB_SaveConfig() to save the hardware configuration.
*  Call the XB_Sleep() function before calling the CyPmSleep() 
*  or the CyPmHibernate() function. 
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  XB_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void XB_Sleep(void)
{
    #if(XB_RX_ENABLED || XB_HD_ENABLED)
        if((XB_RXSTATUS_ACTL_REG  & XB_INT_ENABLE) != 0u)
        {
            XB_backup.enableState = 1u;
        }
        else
        {
            XB_backup.enableState = 0u;
        }
    #else
        if((XB_TXSTATUS_ACTL_REG  & XB_INT_ENABLE) !=0u)
        {
            XB_backup.enableState = 1u;
        }
        else
        {
            XB_backup.enableState = 0u;
        }
    #endif /* End XB_RX_ENABLED || XB_HD_ENABLED*/

    XB_Stop();
    XB_SaveConfig();
}


/*******************************************************************************
* Function Name: XB_Wakeup
********************************************************************************
*
* Summary:
*  This is the preferred API to restore the component to the state when 
*  XB_Sleep() was called. The XB_Wakeup() function
*  calls the XB_RestoreConfig() function to restore the 
*  configuration. If the component was enabled before the 
*  XB_Sleep() function was called, the XB_Wakeup()
*  function will also re-enable the component.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  XB_backup - used when non-retention registers are restored.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void XB_Wakeup(void)
{
    XB_RestoreConfig();
    #if( (XB_RX_ENABLED) || (XB_HD_ENABLED) )
        XB_ClearRxBuffer();
    #endif /* End (XB_RX_ENABLED) || (XB_HD_ENABLED) */
    #if(XB_TX_ENABLED || XB_HD_ENABLED)
        XB_ClearTxBuffer();
    #endif /* End XB_TX_ENABLED || XB_HD_ENABLED */

    if(XB_backup.enableState != 0u)
    {
        XB_Enable();
    }
}


/* [] END OF FILE */
