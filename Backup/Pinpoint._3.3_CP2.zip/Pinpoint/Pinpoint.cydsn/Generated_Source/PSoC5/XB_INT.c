/*******************************************************************************
* File Name: XBINT.c
* Version 2.50
*
* Description:
*  This file provides all Interrupt Service functionality of the UART component
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "XB.h"
#include "cyapicallbacks.h"


/***************************************
* Custom Declarations
***************************************/
/* `#START CUSTOM_DECLARATIONS` Place your declaration here */
/* `#END` */

#if (XB_RX_INTERRUPT_ENABLED && (XB_RX_ENABLED || XB_HD_ENABLED))
    /*******************************************************************************
    * Function Name: XB_RXISR
    ********************************************************************************
    *
    * Summary:
    *  Interrupt Service Routine for RX portion of the UART
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  XB_rxBuffer - RAM buffer pointer for save received data.
    *  XB_rxBufferWrite - cyclic index for write to rxBuffer,
    *     increments after each byte saved to buffer.
    *  XB_rxBufferRead - cyclic index for read from rxBuffer,
    *     checked to detect overflow condition.
    *  XB_rxBufferOverflow - software overflow flag. Set to one
    *     when XB_rxBufferWrite index overtakes
    *     XB_rxBufferRead index.
    *  XB_rxBufferLoopDetect - additional variable to detect overflow.
    *     Set to one when XB_rxBufferWrite is equal to
    *    XB_rxBufferRead
    *  XB_rxAddressMode - this variable contains the Address mode,
    *     selected in customizer or set by UART_SetRxAddressMode() API.
    *  XB_rxAddressDetected - set to 1 when correct address received,
    *     and analysed to store following addressed data bytes to the buffer.
    *     When not correct address received, set to 0 to skip following data bytes.
    *
    *******************************************************************************/
    CY_ISR(XB_RXISR)
    {
        uint8 readData;
        uint8 readStatus;
        uint8 increment_pointer = 0u;

    #if(CY_PSOC3)
        uint8 int_en;
    #endif /* (CY_PSOC3) */

    #ifdef XB_RXISR_ENTRY_CALLBACK
        XB_RXISR_EntryCallback();
    #endif /* XB_RXISR_ENTRY_CALLBACK */

        /* User code required at start of ISR */
        /* `#START XB_RXISR_START` */

        /* `#END` */

    #if(CY_PSOC3)   /* Make sure nested interrupt is enabled */
        int_en = EA;
        CyGlobalIntEnable;
    #endif /* (CY_PSOC3) */

        do
        {
            /* Read receiver status register */
            readStatus = XB_RXSTATUS_REG;
            /* Copy the same status to readData variable for backward compatibility support 
            *  of the user code in XB_RXISR_ERROR` section. 
            */
            readData = readStatus;

            if((readStatus & (XB_RX_STS_BREAK | 
                            XB_RX_STS_PAR_ERROR |
                            XB_RX_STS_STOP_ERROR | 
                            XB_RX_STS_OVERRUN)) != 0u)
            {
                /* ERROR handling. */
                XB_errorStatus |= readStatus & ( XB_RX_STS_BREAK | 
                                                            XB_RX_STS_PAR_ERROR | 
                                                            XB_RX_STS_STOP_ERROR | 
                                                            XB_RX_STS_OVERRUN);
                /* `#START XB_RXISR_ERROR` */

                /* `#END` */
                
            #ifdef XB_RXISR_ERROR_CALLBACK
                XB_RXISR_ERROR_Callback();
            #endif /* XB_RXISR_ERROR_CALLBACK */
            }
            
            if((readStatus & XB_RX_STS_FIFO_NOTEMPTY) != 0u)
            {
                /* Read data from the RX data register */
                readData = XB_RXDATA_REG;
            #if (XB_RXHW_ADDRESS_ENABLED)
                if(XB_rxAddressMode == (uint8)XB__B_UART__AM_SW_DETECT_TO_BUFFER)
                {
                    if((readStatus & XB_RX_STS_MRKSPC) != 0u)
                    {
                        if ((readStatus & XB_RX_STS_ADDR_MATCH) != 0u)
                        {
                            XB_rxAddressDetected = 1u;
                        }
                        else
                        {
                            XB_rxAddressDetected = 0u;
                        }
                    }
                    if(XB_rxAddressDetected != 0u)
                    {   /* Store only addressed data */
                        XB_rxBuffer[XB_rxBufferWrite] = readData;
                        increment_pointer = 1u;
                    }
                }
                else /* Without software addressing */
                {
                    XB_rxBuffer[XB_rxBufferWrite] = readData;
                    increment_pointer = 1u;
                }
            #else  /* Without addressing */
                XB_rxBuffer[XB_rxBufferWrite] = readData;
                increment_pointer = 1u;
            #endif /* (XB_RXHW_ADDRESS_ENABLED) */

                /* Do not increment buffer pointer when skip not addressed data */
                if(increment_pointer != 0u)
                {
                    if(XB_rxBufferLoopDetect != 0u)
                    {   /* Set Software Buffer status Overflow */
                        XB_rxBufferOverflow = 1u;
                    }
                    /* Set next pointer. */
                    XB_rxBufferWrite++;

                    /* Check pointer for a loop condition */
                    if(XB_rxBufferWrite >= XB_RX_BUFFER_SIZE)
                    {
                        XB_rxBufferWrite = 0u;
                    }

                    /* Detect pre-overload condition and set flag */
                    if(XB_rxBufferWrite == XB_rxBufferRead)
                    {
                        XB_rxBufferLoopDetect = 1u;
                        /* When Hardware Flow Control selected */
                        #if (XB_FLOW_CONTROL != 0u)
                            /* Disable RX interrupt mask, it is enabled when user read data from the buffer using APIs */
                            XB_RXSTATUS_MASK_REG  &= (uint8)~XB_RX_STS_FIFO_NOTEMPTY;
                            CyIntClearPending(XB_RX_VECT_NUM);
                            break; /* Break the reading of the FIFO loop, leave the data there for generating RTS signal */
                        #endif /* (XB_FLOW_CONTROL != 0u) */
                    }
                }
            }
        }while((readStatus & XB_RX_STS_FIFO_NOTEMPTY) != 0u);

        /* User code required at end of ISR (Optional) */
        /* `#START XB_RXISR_END` */

        /* `#END` */

    #ifdef XB_RXISR_EXIT_CALLBACK
        XB_RXISR_ExitCallback();
    #endif /* XB_RXISR_EXIT_CALLBACK */

    #if(CY_PSOC3)
        EA = int_en;
    #endif /* (CY_PSOC3) */
    }
    
#endif /* (XB_RX_INTERRUPT_ENABLED && (XB_RX_ENABLED || XB_HD_ENABLED)) */


#if (XB_TX_INTERRUPT_ENABLED && XB_TX_ENABLED)
    /*******************************************************************************
    * Function Name: XB_TXISR
    ********************************************************************************
    *
    * Summary:
    * Interrupt Service Routine for the TX portion of the UART
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  XB_txBuffer - RAM buffer pointer for transmit data from.
    *  XB_txBufferRead - cyclic index for read and transmit data
    *     from txBuffer, increments after each transmitted byte.
    *  XB_rxBufferWrite - cyclic index for write to txBuffer,
    *     checked to detect available for transmission bytes.
    *
    *******************************************************************************/
    CY_ISR(XB_TXISR)
    {
    #if(CY_PSOC3)
        uint8 int_en;
    #endif /* (CY_PSOC3) */

    #ifdef XB_TXISR_ENTRY_CALLBACK
        XB_TXISR_EntryCallback();
    #endif /* XB_TXISR_ENTRY_CALLBACK */

        /* User code required at start of ISR */
        /* `#START XB_TXISR_START` */

        /* `#END` */

    #if(CY_PSOC3)   /* Make sure nested interrupt is enabled */
        int_en = EA;
        CyGlobalIntEnable;
    #endif /* (CY_PSOC3) */

        while((XB_txBufferRead != XB_txBufferWrite) &&
             ((XB_TXSTATUS_REG & XB_TX_STS_FIFO_FULL) == 0u))
        {
            /* Check pointer wrap around */
            if(XB_txBufferRead >= XB_TX_BUFFER_SIZE)
            {
                XB_txBufferRead = 0u;
            }

            XB_TXDATA_REG = XB_txBuffer[XB_txBufferRead];

            /* Set next pointer */
            XB_txBufferRead++;
        }

        /* User code required at end of ISR (Optional) */
        /* `#START XB_TXISR_END` */

        /* `#END` */

    #ifdef XB_TXISR_EXIT_CALLBACK
        XB_TXISR_ExitCallback();
    #endif /* XB_TXISR_EXIT_CALLBACK */

    #if(CY_PSOC3)
        EA = int_en;
    #endif /* (CY_PSOC3) */
   }
#endif /* (XB_TX_INTERRUPT_ENABLED && XB_TX_ENABLED) */


/* [] END OF FILE */
