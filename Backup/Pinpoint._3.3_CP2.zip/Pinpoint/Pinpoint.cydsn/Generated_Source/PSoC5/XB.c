/*******************************************************************************
* File Name: XB.c
* Version 2.50
*
* Description:
*  This file provides all API functionality of the UART component
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "XB.h"
#if (XB_INTERNAL_CLOCK_USED)
    #include "XB_IntClock.h"
#endif /* End XB_INTERNAL_CLOCK_USED */


/***************************************
* Global data allocation
***************************************/

uint8 XB_initVar = 0u;

#if (XB_TX_INTERRUPT_ENABLED && XB_TX_ENABLED)
    volatile uint8 XB_txBuffer[XB_TX_BUFFER_SIZE];
    volatile uint8 XB_txBufferRead = 0u;
    uint8 XB_txBufferWrite = 0u;
#endif /* (XB_TX_INTERRUPT_ENABLED && XB_TX_ENABLED) */

#if (XB_RX_INTERRUPT_ENABLED && (XB_RX_ENABLED || XB_HD_ENABLED))
    uint8 XB_errorStatus = 0u;
    volatile uint8 XB_rxBuffer[XB_RX_BUFFER_SIZE];
    volatile uint8 XB_rxBufferRead  = 0u;
    volatile uint8 XB_rxBufferWrite = 0u;
    volatile uint8 XB_rxBufferLoopDetect = 0u;
    volatile uint8 XB_rxBufferOverflow   = 0u;
    #if (XB_RXHW_ADDRESS_ENABLED)
        volatile uint8 XB_rxAddressMode = XB_RX_ADDRESS_MODE;
        volatile uint8 XB_rxAddressDetected = 0u;
    #endif /* (XB_RXHW_ADDRESS_ENABLED) */
#endif /* (XB_RX_INTERRUPT_ENABLED && (XB_RX_ENABLED || XB_HD_ENABLED)) */


/*******************************************************************************
* Function Name: XB_Start
********************************************************************************
*
* Summary:
*  This is the preferred method to begin component operation.
*  XB_Start() sets the initVar variable, calls the
*  XB_Init() function, and then calls the
*  XB_Enable() function.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global variables:
*  The XB_intiVar variable is used to indicate initial
*  configuration of this component. The variable is initialized to zero (0u)
*  and set to one (1u) the first time XB_Start() is called. This
*  allows for component initialization without re-initialization in all
*  subsequent calls to the XB_Start() routine.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void XB_Start(void) 
{
    /* If not initialized then initialize all required hardware and software */
    if(XB_initVar == 0u)
    {
        XB_Init();
        XB_initVar = 1u;
    }

    XB_Enable();
}


/*******************************************************************************
* Function Name: XB_Init
********************************************************************************
*
* Summary:
*  Initializes or restores the component according to the customizer Configure
*  dialog settings. It is not necessary to call XB_Init() because
*  the XB_Start() API calls this function and is the preferred
*  method to begin component operation.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void XB_Init(void) 
{
    #if(XB_RX_ENABLED || XB_HD_ENABLED)

        #if (XB_RX_INTERRUPT_ENABLED)
            /* Set RX interrupt vector and priority */
            (void) CyIntSetVector(XB_RX_VECT_NUM, &XB_RXISR);
            CyIntSetPriority(XB_RX_VECT_NUM, XB_RX_PRIOR_NUM);
            XB_errorStatus = 0u;
        #endif /* (XB_RX_INTERRUPT_ENABLED) */

        #if (XB_RXHW_ADDRESS_ENABLED)
            XB_SetRxAddressMode(XB_RX_ADDRESS_MODE);
            XB_SetRxAddress1(XB_RX_HW_ADDRESS1);
            XB_SetRxAddress2(XB_RX_HW_ADDRESS2);
        #endif /* End XB_RXHW_ADDRESS_ENABLED */

        /* Init Count7 period */
        XB_RXBITCTR_PERIOD_REG = XB_RXBITCTR_INIT;
        /* Configure the Initial RX interrupt mask */
        XB_RXSTATUS_MASK_REG  = XB_INIT_RX_INTERRUPTS_MASK;
    #endif /* End XB_RX_ENABLED || XB_HD_ENABLED*/

    #if(XB_TX_ENABLED)
        #if (XB_TX_INTERRUPT_ENABLED)
            /* Set TX interrupt vector and priority */
            (void) CyIntSetVector(XB_TX_VECT_NUM, &XB_TXISR);
            CyIntSetPriority(XB_TX_VECT_NUM, XB_TX_PRIOR_NUM);
        #endif /* (XB_TX_INTERRUPT_ENABLED) */

        /* Write Counter Value for TX Bit Clk Generator*/
        #if (XB_TXCLKGEN_DP)
            XB_TXBITCLKGEN_CTR_REG = XB_BIT_CENTER;
            XB_TXBITCLKTX_COMPLETE_REG = ((XB_NUMBER_OF_DATA_BITS +
                        XB_NUMBER_OF_START_BIT) * XB_OVER_SAMPLE_COUNT) - 1u;
        #else
            XB_TXBITCTR_PERIOD_REG = ((XB_NUMBER_OF_DATA_BITS +
                        XB_NUMBER_OF_START_BIT) * XB_OVER_SAMPLE_8) - 1u;
        #endif /* End XB_TXCLKGEN_DP */

        /* Configure the Initial TX interrupt mask */
        #if (XB_TX_INTERRUPT_ENABLED)
            XB_TXSTATUS_MASK_REG = XB_TX_STS_FIFO_EMPTY;
        #else
            XB_TXSTATUS_MASK_REG = XB_INIT_TX_INTERRUPTS_MASK;
        #endif /*End XB_TX_INTERRUPT_ENABLED*/

    #endif /* End XB_TX_ENABLED */

    #if(XB_PARITY_TYPE_SW)  /* Write Parity to Control Register */
        XB_WriteControlRegister( \
            (XB_ReadControlRegister() & (uint8)~XB_CTRL_PARITY_TYPE_MASK) | \
            (uint8)(XB_PARITY_TYPE << XB_CTRL_PARITY_TYPE0_SHIFT) );
    #endif /* End XB_PARITY_TYPE_SW */
}


/*******************************************************************************
* Function Name: XB_Enable
********************************************************************************
*
* Summary:
*  Activates the hardware and begins component operation. It is not necessary
*  to call XB_Enable() because the XB_Start() API
*  calls this function, which is the preferred method to begin component
*  operation.

* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  XB_rxAddressDetected - set to initial state (0).
*
*******************************************************************************/
void XB_Enable(void) 
{
    uint8 enableInterrupts;
    enableInterrupts = CyEnterCriticalSection();

    #if (XB_RX_ENABLED || XB_HD_ENABLED)
        /* RX Counter (Count7) Enable */
        XB_RXBITCTR_CONTROL_REG |= XB_CNTR_ENABLE;

        /* Enable the RX Interrupt */
        XB_RXSTATUS_ACTL_REG  |= XB_INT_ENABLE;

        #if (XB_RX_INTERRUPT_ENABLED)
            XB_EnableRxInt();

            #if (XB_RXHW_ADDRESS_ENABLED)
                XB_rxAddressDetected = 0u;
            #endif /* (XB_RXHW_ADDRESS_ENABLED) */
        #endif /* (XB_RX_INTERRUPT_ENABLED) */
    #endif /* (XB_RX_ENABLED || XB_HD_ENABLED) */

    #if(XB_TX_ENABLED)
        /* TX Counter (DP/Count7) Enable */
        #if(!XB_TXCLKGEN_DP)
            XB_TXBITCTR_CONTROL_REG |= XB_CNTR_ENABLE;
        #endif /* End XB_TXCLKGEN_DP */

        /* Enable the TX Interrupt */
        XB_TXSTATUS_ACTL_REG |= XB_INT_ENABLE;
        #if (XB_TX_INTERRUPT_ENABLED)
            XB_ClearPendingTxInt(); /* Clear history of TX_NOT_EMPTY */
            XB_EnableTxInt();
        #endif /* (XB_TX_INTERRUPT_ENABLED) */
     #endif /* (XB_TX_INTERRUPT_ENABLED) */

    #if (XB_INTERNAL_CLOCK_USED)
        XB_IntClock_Start();  /* Enable the clock */
    #endif /* (XB_INTERNAL_CLOCK_USED) */

    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: XB_Stop
********************************************************************************
*
* Summary:
*  Disables the UART operation.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void XB_Stop(void) 
{
    uint8 enableInterrupts;
    enableInterrupts = CyEnterCriticalSection();

    /* Write Bit Counter Disable */
    #if (XB_RX_ENABLED || XB_HD_ENABLED)
        XB_RXBITCTR_CONTROL_REG &= (uint8) ~XB_CNTR_ENABLE;
    #endif /* (XB_RX_ENABLED || XB_HD_ENABLED) */

    #if (XB_TX_ENABLED)
        #if(!XB_TXCLKGEN_DP)
            XB_TXBITCTR_CONTROL_REG &= (uint8) ~XB_CNTR_ENABLE;
        #endif /* (!XB_TXCLKGEN_DP) */
    #endif /* (XB_TX_ENABLED) */

    #if (XB_INTERNAL_CLOCK_USED)
        XB_IntClock_Stop();   /* Disable the clock */
    #endif /* (XB_INTERNAL_CLOCK_USED) */

    /* Disable internal interrupt component */
    #if (XB_RX_ENABLED || XB_HD_ENABLED)
        XB_RXSTATUS_ACTL_REG  &= (uint8) ~XB_INT_ENABLE;

        #if (XB_RX_INTERRUPT_ENABLED)
            XB_DisableRxInt();
        #endif /* (XB_RX_INTERRUPT_ENABLED) */
    #endif /* (XB_RX_ENABLED || XB_HD_ENABLED) */

    #if (XB_TX_ENABLED)
        XB_TXSTATUS_ACTL_REG &= (uint8) ~XB_INT_ENABLE;

        #if (XB_TX_INTERRUPT_ENABLED)
            XB_DisableTxInt();
        #endif /* (XB_TX_INTERRUPT_ENABLED) */
    #endif /* (XB_TX_ENABLED) */

    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: XB_ReadControlRegister
********************************************************************************
*
* Summary:
*  Returns the current value of the control register.
*
* Parameters:
*  None.
*
* Return:
*  Contents of the control register.
*
*******************************************************************************/
uint8 XB_ReadControlRegister(void) 
{
    #if (XB_CONTROL_REG_REMOVED)
        return(0u);
    #else
        return(XB_CONTROL_REG);
    #endif /* (XB_CONTROL_REG_REMOVED) */
}


/*******************************************************************************
* Function Name: XB_WriteControlRegister
********************************************************************************
*
* Summary:
*  Writes an 8-bit value into the control register
*
* Parameters:
*  control:  control register value
*
* Return:
*  None.
*
*******************************************************************************/
void  XB_WriteControlRegister(uint8 control) 
{
    #if (XB_CONTROL_REG_REMOVED)
        if(0u != control)
        {
            /* Suppress compiler warning */
        }
    #else
       XB_CONTROL_REG = control;
    #endif /* (XB_CONTROL_REG_REMOVED) */
}


#if(XB_RX_ENABLED || XB_HD_ENABLED)
    /*******************************************************************************
    * Function Name: XB_SetRxInterruptMode
    ********************************************************************************
    *
    * Summary:
    *  Configures the RX interrupt sources enabled.
    *
    * Parameters:
    *  IntSrc:  Bit field containing the RX interrupts to enable. Based on the 
    *  bit-field arrangement of the status register. This value must be a 
    *  combination of status register bit-masks shown below:
    *      XB_RX_STS_FIFO_NOTEMPTY    Interrupt on byte received.
    *      XB_RX_STS_PAR_ERROR        Interrupt on parity error.
    *      XB_RX_STS_STOP_ERROR       Interrupt on stop error.
    *      XB_RX_STS_BREAK            Interrupt on break.
    *      XB_RX_STS_OVERRUN          Interrupt on overrun error.
    *      XB_RX_STS_ADDR_MATCH       Interrupt on address match.
    *      XB_RX_STS_MRKSPC           Interrupt on address detect.
    *
    * Return:
    *  None.
    *
    * Theory:
    *  Enables the output of specific status bits to the interrupt controller
    *
    *******************************************************************************/
    void XB_SetRxInterruptMode(uint8 intSrc) 
    {
        XB_RXSTATUS_MASK_REG  = intSrc;
    }


    /*******************************************************************************
    * Function Name: XB_ReadRxData
    ********************************************************************************
    *
    * Summary:
    *  Returns the next byte of received data. This function returns data without
    *  checking the status. You must check the status separately.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  Received data from RX register
    *
    * Global Variables:
    *  XB_rxBuffer - RAM buffer pointer for save received data.
    *  XB_rxBufferWrite - cyclic index for write to rxBuffer,
    *     checked to identify new data.
    *  XB_rxBufferRead - cyclic index for read from rxBuffer,
    *     incremented after each byte has been read from buffer.
    *  XB_rxBufferLoopDetect - cleared if loop condition was detected
    *     in RX ISR.
    *
    * Reentrant:
    *  No.
    *
    *******************************************************************************/
    uint8 XB_ReadRxData(void) 
    {
        uint8 rxData;

    #if (XB_RX_INTERRUPT_ENABLED)

        uint8 locRxBufferRead;
        uint8 locRxBufferWrite;

        /* Protect variables that could change on interrupt */
        XB_DisableRxInt();

        locRxBufferRead  = XB_rxBufferRead;
        locRxBufferWrite = XB_rxBufferWrite;

        if( (XB_rxBufferLoopDetect != 0u) || (locRxBufferRead != locRxBufferWrite) )
        {
            rxData = XB_rxBuffer[locRxBufferRead];
            locRxBufferRead++;

            if(locRxBufferRead >= XB_RX_BUFFER_SIZE)
            {
                locRxBufferRead = 0u;
            }
            /* Update the real pointer */
            XB_rxBufferRead = locRxBufferRead;

            if(XB_rxBufferLoopDetect != 0u)
            {
                XB_rxBufferLoopDetect = 0u;
                #if ((XB_RX_INTERRUPT_ENABLED) && (XB_FLOW_CONTROL != 0u))
                    /* When Hardware Flow Control selected - return RX mask */
                    #if( XB_HD_ENABLED )
                        if((XB_CONTROL_REG & XB_CTRL_HD_SEND) == 0u)
                        {   /* In Half duplex mode return RX mask only in RX
                            *  configuration set, otherwise
                            *  mask will be returned in LoadRxConfig() API.
                            */
                            XB_RXSTATUS_MASK_REG  |= XB_RX_STS_FIFO_NOTEMPTY;
                        }
                    #else
                        XB_RXSTATUS_MASK_REG  |= XB_RX_STS_FIFO_NOTEMPTY;
                    #endif /* end XB_HD_ENABLED */
                #endif /* ((XB_RX_INTERRUPT_ENABLED) && (XB_FLOW_CONTROL != 0u)) */
            }
        }
        else
        {   /* Needs to check status for RX_STS_FIFO_NOTEMPTY bit */
            rxData = XB_RXDATA_REG;
        }

        XB_EnableRxInt();

    #else

        /* Needs to check status for RX_STS_FIFO_NOTEMPTY bit */
        rxData = XB_RXDATA_REG;

    #endif /* (XB_RX_INTERRUPT_ENABLED) */

        return(rxData);
    }


    /*******************************************************************************
    * Function Name: XB_ReadRxStatus
    ********************************************************************************
    *
    * Summary:
    *  Returns the current state of the receiver status register and the software
    *  buffer overflow status.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  Current state of the status register.
    *
    * Side Effect:
    *  All status register bits are clear-on-read except
    *  XB_RX_STS_FIFO_NOTEMPTY.
    *  XB_RX_STS_FIFO_NOTEMPTY clears immediately after RX data
    *  register read.
    *
    * Global Variables:
    *  XB_rxBufferOverflow - used to indicate overload condition.
    *   It set to one in RX interrupt when there isn't free space in
    *   XB_rxBufferRead to write new data. This condition returned
    *   and cleared to zero by this API as an
    *   XB_RX_STS_SOFT_BUFF_OVER bit along with RX Status register
    *   bits.
    *
    *******************************************************************************/
    uint8 XB_ReadRxStatus(void) 
    {
        uint8 status;

        status = XB_RXSTATUS_REG & XB_RX_HW_MASK;

    #if (XB_RX_INTERRUPT_ENABLED)
        if(XB_rxBufferOverflow != 0u)
        {
            status |= XB_RX_STS_SOFT_BUFF_OVER;
            XB_rxBufferOverflow = 0u;
        }
    #endif /* (XB_RX_INTERRUPT_ENABLED) */

        return(status);
    }


    /*******************************************************************************
    * Function Name: XB_GetChar
    ********************************************************************************
    *
    * Summary:
    *  Returns the last received byte of data. XB_GetChar() is
    *  designed for ASCII characters and returns a uint8 where 1 to 255 are values
    *  for valid characters and 0 indicates an error occurred or no data is present.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  Character read from UART RX buffer. ASCII characters from 1 to 255 are valid.
    *  A returned zero signifies an error condition or no data available.
    *
    * Global Variables:
    *  XB_rxBuffer - RAM buffer pointer for save received data.
    *  XB_rxBufferWrite - cyclic index for write to rxBuffer,
    *     checked to identify new data.
    *  XB_rxBufferRead - cyclic index for read from rxBuffer,
    *     incremented after each byte has been read from buffer.
    *  XB_rxBufferLoopDetect - cleared if loop condition was detected
    *     in RX ISR.
    *
    * Reentrant:
    *  No.
    *
    *******************************************************************************/
    uint8 XB_GetChar(void) 
    {
        uint8 rxData = 0u;
        uint8 rxStatus;

    #if (XB_RX_INTERRUPT_ENABLED)
        uint8 locRxBufferRead;
        uint8 locRxBufferWrite;

        /* Protect variables that could change on interrupt */
        XB_DisableRxInt();

        locRxBufferRead  = XB_rxBufferRead;
        locRxBufferWrite = XB_rxBufferWrite;

        if( (XB_rxBufferLoopDetect != 0u) || (locRxBufferRead != locRxBufferWrite) )
        {
            rxData = XB_rxBuffer[locRxBufferRead];
            locRxBufferRead++;
            if(locRxBufferRead >= XB_RX_BUFFER_SIZE)
            {
                locRxBufferRead = 0u;
            }
            /* Update the real pointer */
            XB_rxBufferRead = locRxBufferRead;

            if(XB_rxBufferLoopDetect != 0u)
            {
                XB_rxBufferLoopDetect = 0u;
                #if( (XB_RX_INTERRUPT_ENABLED) && (XB_FLOW_CONTROL != 0u) )
                    /* When Hardware Flow Control selected - return RX mask */
                    #if( XB_HD_ENABLED )
                        if((XB_CONTROL_REG & XB_CTRL_HD_SEND) == 0u)
                        {   /* In Half duplex mode return RX mask only if
                            *  RX configuration set, otherwise
                            *  mask will be returned in LoadRxConfig() API.
                            */
                            XB_RXSTATUS_MASK_REG |= XB_RX_STS_FIFO_NOTEMPTY;
                        }
                    #else
                        XB_RXSTATUS_MASK_REG |= XB_RX_STS_FIFO_NOTEMPTY;
                    #endif /* end XB_HD_ENABLED */
                #endif /* XB_RX_INTERRUPT_ENABLED and Hardware flow control*/
            }

        }
        else
        {   rxStatus = XB_RXSTATUS_REG;
            if((rxStatus & XB_RX_STS_FIFO_NOTEMPTY) != 0u)
            {   /* Read received data from FIFO */
                rxData = XB_RXDATA_REG;
                /*Check status on error*/
                if((rxStatus & (XB_RX_STS_BREAK | XB_RX_STS_PAR_ERROR |
                                XB_RX_STS_STOP_ERROR | XB_RX_STS_OVERRUN)) != 0u)
                {
                    rxData = 0u;
                }
            }
        }

        XB_EnableRxInt();

    #else

        rxStatus =XB_RXSTATUS_REG;
        if((rxStatus & XB_RX_STS_FIFO_NOTEMPTY) != 0u)
        {
            /* Read received data from FIFO */
            rxData = XB_RXDATA_REG;

            /*Check status on error*/
            if((rxStatus & (XB_RX_STS_BREAK | XB_RX_STS_PAR_ERROR |
                            XB_RX_STS_STOP_ERROR | XB_RX_STS_OVERRUN)) != 0u)
            {
                rxData = 0u;
            }
        }
    #endif /* (XB_RX_INTERRUPT_ENABLED) */

        return(rxData);
    }


    /*******************************************************************************
    * Function Name: XB_GetByte
    ********************************************************************************
    *
    * Summary:
    *  Reads UART RX buffer immediately, returns received character and error
    *  condition.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  MSB contains status and LSB contains UART RX data. If the MSB is nonzero,
    *  an error has occurred.
    *
    * Reentrant:
    *  No.
    *
    *******************************************************************************/
    uint16 XB_GetByte(void) 
    {
        
    #if (XB_RX_INTERRUPT_ENABLED)
        uint16 locErrorStatus;
        /* Protect variables that could change on interrupt */
        XB_DisableRxInt();
        locErrorStatus = (uint16)XB_errorStatus;
        XB_errorStatus = 0u;
        XB_EnableRxInt();
        return ( (uint16)(locErrorStatus << 8u) | XB_ReadRxData() );
    #else
        return ( ((uint16)XB_ReadRxStatus() << 8u) | XB_ReadRxData() );
    #endif /* XB_RX_INTERRUPT_ENABLED */
        
    }


    /*******************************************************************************
    * Function Name: XB_GetRxBufferSize
    ********************************************************************************
    *
    * Summary:
    *  Returns the number of received bytes available in the RX buffer.
    *  * RX software buffer is disabled (RX Buffer Size parameter is equal to 4): 
    *    returns 0 for empty RX FIFO or 1 for not empty RX FIFO.
    *  * RX software buffer is enabled: returns the number of bytes available in 
    *    the RX software buffer. Bytes available in the RX FIFO do not take to 
    *    account.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  uint8: Number of bytes in the RX buffer. 
    *    Return value type depends on RX Buffer Size parameter.
    *
    * Global Variables:
    *  XB_rxBufferWrite - used to calculate left bytes.
    *  XB_rxBufferRead - used to calculate left bytes.
    *  XB_rxBufferLoopDetect - checked to decide left bytes amount.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  Allows the user to find out how full the RX Buffer is.
    *
    *******************************************************************************/
    uint8 XB_GetRxBufferSize(void)
                                                            
    {
        uint8 size;

    #if (XB_RX_INTERRUPT_ENABLED)

        /* Protect variables that could change on interrupt */
        XB_DisableRxInt();

        if(XB_rxBufferRead == XB_rxBufferWrite)
        {
            if(XB_rxBufferLoopDetect != 0u)
            {
                size = XB_RX_BUFFER_SIZE;
            }
            else
            {
                size = 0u;
            }
        }
        else if(XB_rxBufferRead < XB_rxBufferWrite)
        {
            size = (XB_rxBufferWrite - XB_rxBufferRead);
        }
        else
        {
            size = (XB_RX_BUFFER_SIZE - XB_rxBufferRead) + XB_rxBufferWrite;
        }

        XB_EnableRxInt();

    #else

        /* We can only know if there is data in the fifo. */
        size = ((XB_RXSTATUS_REG & XB_RX_STS_FIFO_NOTEMPTY) != 0u) ? 1u : 0u;

    #endif /* (XB_RX_INTERRUPT_ENABLED) */

        return(size);
    }


    /*******************************************************************************
    * Function Name: XB_ClearRxBuffer
    ********************************************************************************
    *
    * Summary:
    *  Clears the receiver memory buffer and hardware RX FIFO of all received data.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  XB_rxBufferWrite - cleared to zero.
    *  XB_rxBufferRead - cleared to zero.
    *  XB_rxBufferLoopDetect - cleared to zero.
    *  XB_rxBufferOverflow - cleared to zero.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  Setting the pointers to zero makes the system believe there is no data to
    *  read and writing will resume at address 0 overwriting any data that may
    *  have remained in the RAM.
    *
    * Side Effects:
    *  Any received data not read from the RAM or FIFO buffer will be lost.
    *
    *******************************************************************************/
    void XB_ClearRxBuffer(void) 
    {
        uint8 enableInterrupts;

        /* Clear the HW FIFO */
        enableInterrupts = CyEnterCriticalSection();
        XB_RXDATA_AUX_CTL_REG |= (uint8)  XB_RX_FIFO_CLR;
        XB_RXDATA_AUX_CTL_REG &= (uint8) ~XB_RX_FIFO_CLR;
        CyExitCriticalSection(enableInterrupts);

    #if (XB_RX_INTERRUPT_ENABLED)

        /* Protect variables that could change on interrupt. */
        XB_DisableRxInt();

        XB_rxBufferRead = 0u;
        XB_rxBufferWrite = 0u;
        XB_rxBufferLoopDetect = 0u;
        XB_rxBufferOverflow = 0u;

        XB_EnableRxInt();

    #endif /* (XB_RX_INTERRUPT_ENABLED) */

    }


    /*******************************************************************************
    * Function Name: XB_SetRxAddressMode
    ********************************************************************************
    *
    * Summary:
    *  Sets the software controlled Addressing mode used by the RX portion of the
    *  UART.
    *
    * Parameters:
    *  addressMode: Enumerated value indicating the mode of RX addressing
    *  XB__B_UART__AM_SW_BYTE_BYTE -  Software Byte-by-Byte address
    *                                               detection
    *  XB__B_UART__AM_SW_DETECT_TO_BUFFER - Software Detect to Buffer
    *                                               address detection
    *  XB__B_UART__AM_HW_BYTE_BY_BYTE - Hardware Byte-by-Byte address
    *                                               detection
    *  XB__B_UART__AM_HW_DETECT_TO_BUFFER - Hardware Detect to Buffer
    *                                               address detection
    *  XB__B_UART__AM_NONE - No address detection
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  XB_rxAddressMode - the parameter stored in this variable for
    *   the farther usage in RX ISR.
    *  XB_rxAddressDetected - set to initial state (0).
    *
    *******************************************************************************/
    void XB_SetRxAddressMode(uint8 addressMode)
                                                        
    {
        #if(XB_RXHW_ADDRESS_ENABLED)
            #if(XB_CONTROL_REG_REMOVED)
                if(0u != addressMode)
                {
                    /* Suppress compiler warning */
                }
            #else /* XB_CONTROL_REG_REMOVED */
                uint8 tmpCtrl;
                tmpCtrl = XB_CONTROL_REG & (uint8)~XB_CTRL_RXADDR_MODE_MASK;
                tmpCtrl |= (uint8)(addressMode << XB_CTRL_RXADDR_MODE0_SHIFT);
                XB_CONTROL_REG = tmpCtrl;

                #if(XB_RX_INTERRUPT_ENABLED && \
                   (XB_RXBUFFERSIZE > XB_FIFO_LENGTH) )
                    XB_rxAddressMode = addressMode;
                    XB_rxAddressDetected = 0u;
                #endif /* End XB_RXBUFFERSIZE > XB_FIFO_LENGTH*/
            #endif /* End XB_CONTROL_REG_REMOVED */
        #else /* XB_RXHW_ADDRESS_ENABLED */
            if(0u != addressMode)
            {
                /* Suppress compiler warning */
            }
        #endif /* End XB_RXHW_ADDRESS_ENABLED */
    }


    /*******************************************************************************
    * Function Name: XB_SetRxAddress1
    ********************************************************************************
    *
    * Summary:
    *  Sets the first of two hardware-detectable receiver addresses.
    *
    * Parameters:
    *  address: Address #1 for hardware address detection.
    *
    * Return:
    *  None.
    *
    *******************************************************************************/
    void XB_SetRxAddress1(uint8 address) 
    {
        XB_RXADDRESS1_REG = address;
    }


    /*******************************************************************************
    * Function Name: XB_SetRxAddress2
    ********************************************************************************
    *
    * Summary:
    *  Sets the second of two hardware-detectable receiver addresses.
    *
    * Parameters:
    *  address: Address #2 for hardware address detection.
    *
    * Return:
    *  None.
    *
    *******************************************************************************/
    void XB_SetRxAddress2(uint8 address) 
    {
        XB_RXADDRESS2_REG = address;
    }

#endif  /* XB_RX_ENABLED || XB_HD_ENABLED*/


#if( (XB_TX_ENABLED) || (XB_HD_ENABLED) )
    /*******************************************************************************
    * Function Name: XB_SetTxInterruptMode
    ********************************************************************************
    *
    * Summary:
    *  Configures the TX interrupt sources to be enabled, but does not enable the
    *  interrupt.
    *
    * Parameters:
    *  intSrc: Bit field containing the TX interrupt sources to enable
    *   XB_TX_STS_COMPLETE        Interrupt on TX byte complete
    *   XB_TX_STS_FIFO_EMPTY      Interrupt when TX FIFO is empty
    *   XB_TX_STS_FIFO_FULL       Interrupt when TX FIFO is full
    *   XB_TX_STS_FIFO_NOT_FULL   Interrupt when TX FIFO is not full
    *
    * Return:
    *  None.
    *
    * Theory:
    *  Enables the output of specific status bits to the interrupt controller
    *
    *******************************************************************************/
    void XB_SetTxInterruptMode(uint8 intSrc) 
    {
        XB_TXSTATUS_MASK_REG = intSrc;
    }


    /*******************************************************************************
    * Function Name: XB_WriteTxData
    ********************************************************************************
    *
    * Summary:
    *  Places a byte of data into the transmit buffer to be sent when the bus is
    *  available without checking the TX status register. You must check status
    *  separately.
    *
    * Parameters:
    *  txDataByte: data byte
    *
    * Return:
    * None.
    *
    * Global Variables:
    *  XB_txBuffer - RAM buffer pointer for save data for transmission
    *  XB_txBufferWrite - cyclic index for write to txBuffer,
    *    incremented after each byte saved to buffer.
    *  XB_txBufferRead - cyclic index for read from txBuffer,
    *    checked to identify the condition to write to FIFO directly or to TX buffer
    *  XB_initVar - checked to identify that the component has been
    *    initialized.
    *
    * Reentrant:
    *  No.
    *
    *******************************************************************************/
    void XB_WriteTxData(uint8 txDataByte) 
    {
        /* If not Initialized then skip this function*/
        if(XB_initVar != 0u)
        {
        #if (XB_TX_INTERRUPT_ENABLED)

            /* Protect variables that could change on interrupt. */
            XB_DisableTxInt();

            if( (XB_txBufferRead == XB_txBufferWrite) &&
                ((XB_TXSTATUS_REG & XB_TX_STS_FIFO_FULL) == 0u) )
            {
                /* Add directly to the FIFO. */
                XB_TXDATA_REG = txDataByte;
            }
            else
            {
                if(XB_txBufferWrite >= XB_TX_BUFFER_SIZE)
                {
                    XB_txBufferWrite = 0u;
                }

                XB_txBuffer[XB_txBufferWrite] = txDataByte;

                /* Add to the software buffer. */
                XB_txBufferWrite++;
            }

            XB_EnableTxInt();

        #else

            /* Add directly to the FIFO. */
            XB_TXDATA_REG = txDataByte;

        #endif /*(XB_TX_INTERRUPT_ENABLED) */
        }
    }


    /*******************************************************************************
    * Function Name: XB_ReadTxStatus
    ********************************************************************************
    *
    * Summary:
    *  Reads the status register for the TX portion of the UART.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  Contents of the status register
    *
    * Theory:
    *  This function reads the TX status register, which is cleared on read.
    *  It is up to the user to handle all bits in this return value accordingly,
    *  even if the bit was not enabled as an interrupt source the event happened
    *  and must be handled accordingly.
    *
    *******************************************************************************/
    uint8 XB_ReadTxStatus(void) 
    {
        return(XB_TXSTATUS_REG);
    }


    /*******************************************************************************
    * Function Name: XB_PutChar
    ********************************************************************************
    *
    * Summary:
    *  Puts a byte of data into the transmit buffer to be sent when the bus is
    *  available. This is a blocking API that waits until the TX buffer has room to
    *  hold the data.
    *
    * Parameters:
    *  txDataByte: Byte containing the data to transmit
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  XB_txBuffer - RAM buffer pointer for save data for transmission
    *  XB_txBufferWrite - cyclic index for write to txBuffer,
    *     checked to identify free space in txBuffer and incremented after each byte
    *     saved to buffer.
    *  XB_txBufferRead - cyclic index for read from txBuffer,
    *     checked to identify free space in txBuffer.
    *  XB_initVar - checked to identify that the component has been
    *     initialized.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  Allows the user to transmit any byte of data in a single transfer
    *
    *******************************************************************************/
    void XB_PutChar(uint8 txDataByte) 
    {
    #if (XB_TX_INTERRUPT_ENABLED)
        /* The temporary output pointer is used since it takes two instructions
        *  to increment with a wrap, and we can't risk doing that with the real
        *  pointer and getting an interrupt in between instructions.
        */
        uint8 locTxBufferWrite;
        uint8 locTxBufferRead;

        do
        { /* Block if software buffer is full, so we don't overwrite. */

        #if ((XB_TX_BUFFER_SIZE > XB_MAX_BYTE_VALUE) && (CY_PSOC3))
            /* Disable TX interrupt to protect variables from modification */
            XB_DisableTxInt();
        #endif /* (XB_TX_BUFFER_SIZE > XB_MAX_BYTE_VALUE) && (CY_PSOC3) */

            locTxBufferWrite = XB_txBufferWrite;
            locTxBufferRead  = XB_txBufferRead;

        #if ((XB_TX_BUFFER_SIZE > XB_MAX_BYTE_VALUE) && (CY_PSOC3))
            /* Enable interrupt to continue transmission */
            XB_EnableTxInt();
        #endif /* (XB_TX_BUFFER_SIZE > XB_MAX_BYTE_VALUE) && (CY_PSOC3) */
        }
        while( (locTxBufferWrite < locTxBufferRead) ? (locTxBufferWrite == (locTxBufferRead - 1u)) :
                                ((locTxBufferWrite - locTxBufferRead) ==
                                (uint8)(XB_TX_BUFFER_SIZE - 1u)) );

        if( (locTxBufferRead == locTxBufferWrite) &&
            ((XB_TXSTATUS_REG & XB_TX_STS_FIFO_FULL) == 0u) )
        {
            /* Add directly to the FIFO */
            XB_TXDATA_REG = txDataByte;
        }
        else
        {
            if(locTxBufferWrite >= XB_TX_BUFFER_SIZE)
            {
                locTxBufferWrite = 0u;
            }
            /* Add to the software buffer. */
            XB_txBuffer[locTxBufferWrite] = txDataByte;
            locTxBufferWrite++;

            /* Finally, update the real output pointer */
        #if ((XB_TX_BUFFER_SIZE > XB_MAX_BYTE_VALUE) && (CY_PSOC3))
            XB_DisableTxInt();
        #endif /* (XB_TX_BUFFER_SIZE > XB_MAX_BYTE_VALUE) && (CY_PSOC3) */

            XB_txBufferWrite = locTxBufferWrite;

        #if ((XB_TX_BUFFER_SIZE > XB_MAX_BYTE_VALUE) && (CY_PSOC3))
            XB_EnableTxInt();
        #endif /* (XB_TX_BUFFER_SIZE > XB_MAX_BYTE_VALUE) && (CY_PSOC3) */

            if(0u != (XB_TXSTATUS_REG & XB_TX_STS_FIFO_EMPTY))
            {
                /* Trigger TX interrupt to send software buffer */
                XB_SetPendingTxInt();
            }
        }

    #else

        while((XB_TXSTATUS_REG & XB_TX_STS_FIFO_FULL) != 0u)
        {
            /* Wait for room in the FIFO */
        }

        /* Add directly to the FIFO */
        XB_TXDATA_REG = txDataByte;

    #endif /* XB_TX_INTERRUPT_ENABLED */
    }


    /*******************************************************************************
    * Function Name: XB_PutString
    ********************************************************************************
    *
    * Summary:
    *  Sends a NULL terminated string to the TX buffer for transmission.
    *
    * Parameters:
    *  string[]: Pointer to the null terminated string array residing in RAM or ROM
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  XB_initVar - checked to identify that the component has been
    *     initialized.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  If there is not enough memory in the TX buffer for the entire string, this
    *  function blocks until the last character of the string is loaded into the
    *  TX buffer.
    *
    *******************************************************************************/
    void XB_PutString(const char8 string[]) 
    {
        uint16 bufIndex = 0u;

        /* If not Initialized then skip this function */
        if(XB_initVar != 0u)
        {
            /* This is a blocking function, it will not exit until all data is sent */
            while(string[bufIndex] != (char8) 0)
            {
                XB_PutChar((uint8)string[bufIndex]);
                bufIndex++;
            }
        }
    }


    /*******************************************************************************
    * Function Name: XB_PutArray
    ********************************************************************************
    *
    * Summary:
    *  Places N bytes of data from a memory array into the TX buffer for
    *  transmission.
    *
    * Parameters:
    *  string[]: Address of the memory array residing in RAM or ROM.
    *  byteCount: Number of bytes to be transmitted. The type depends on TX Buffer
    *             Size parameter.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  XB_initVar - checked to identify that the component has been
    *     initialized.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  If there is not enough memory in the TX buffer for the entire string, this
    *  function blocks until the last character of the string is loaded into the
    *  TX buffer.
    *
    *******************************************************************************/
    void XB_PutArray(const uint8 string[], uint8 byteCount)
                                                                    
    {
        uint8 bufIndex = 0u;

        /* If not Initialized then skip this function */
        if(XB_initVar != 0u)
        {
            while(bufIndex < byteCount)
            {
                XB_PutChar(string[bufIndex]);
                bufIndex++;
            }
        }
    }


    /*******************************************************************************
    * Function Name: XB_PutCRLF
    ********************************************************************************
    *
    * Summary:
    *  Writes a byte of data followed by a carriage return (0x0D) and line feed
    *  (0x0A) to the transmit buffer.
    *
    * Parameters:
    *  txDataByte: Data byte to transmit before the carriage return and line feed.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  XB_initVar - checked to identify that the component has been
    *     initialized.
    *
    * Reentrant:
    *  No.
    *
    *******************************************************************************/
    void XB_PutCRLF(uint8 txDataByte) 
    {
        /* If not Initialized then skip this function */
        if(XB_initVar != 0u)
        {
            XB_PutChar(txDataByte);
            XB_PutChar(0x0Du);
            XB_PutChar(0x0Au);
        }
    }


    /*******************************************************************************
    * Function Name: XB_GetTxBufferSize
    ********************************************************************************
    *
    * Summary:
    *  Returns the number of bytes in the TX buffer which are waiting to be 
    *  transmitted.
    *  * TX software buffer is disabled (TX Buffer Size parameter is equal to 4): 
    *    returns 0 for empty TX FIFO, 1 for not full TX FIFO or 4 for full TX FIFO.
    *  * TX software buffer is enabled: returns the number of bytes in the TX 
    *    software buffer which are waiting to be transmitted. Bytes available in the
    *    TX FIFO do not count.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  Number of bytes used in the TX buffer. Return value type depends on the TX 
    *  Buffer Size parameter.
    *
    * Global Variables:
    *  XB_txBufferWrite - used to calculate left space.
    *  XB_txBufferRead - used to calculate left space.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  Allows the user to find out how full the TX Buffer is.
    *
    *******************************************************************************/
    uint8 XB_GetTxBufferSize(void)
                                                            
    {
        uint8 size;

    #if (XB_TX_INTERRUPT_ENABLED)

        /* Protect variables that could change on interrupt. */
        XB_DisableTxInt();

        if(XB_txBufferRead == XB_txBufferWrite)
        {
            size = 0u;
        }
        else if(XB_txBufferRead < XB_txBufferWrite)
        {
            size = (XB_txBufferWrite - XB_txBufferRead);
        }
        else
        {
            size = (XB_TX_BUFFER_SIZE - XB_txBufferRead) +
                    XB_txBufferWrite;
        }

        XB_EnableTxInt();

    #else

        size = XB_TXSTATUS_REG;

        /* Is the fifo is full. */
        if((size & XB_TX_STS_FIFO_FULL) != 0u)
        {
            size = XB_FIFO_LENGTH;
        }
        else if((size & XB_TX_STS_FIFO_EMPTY) != 0u)
        {
            size = 0u;
        }
        else
        {
            /* We only know there is data in the fifo. */
            size = 1u;
        }

    #endif /* (XB_TX_INTERRUPT_ENABLED) */

    return(size);
    }


    /*******************************************************************************
    * Function Name: XB_ClearTxBuffer
    ********************************************************************************
    *
    * Summary:
    *  Clears all data from the TX buffer and hardware TX FIFO.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  XB_txBufferWrite - cleared to zero.
    *  XB_txBufferRead - cleared to zero.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  Setting the pointers to zero makes the system believe there is no data to
    *  read and writing will resume at address 0 overwriting any data that may have
    *  remained in the RAM.
    *
    * Side Effects:
    *  Data waiting in the transmit buffer is not sent; a byte that is currently
    *  transmitting finishes transmitting.
    *
    *******************************************************************************/
    void XB_ClearTxBuffer(void) 
    {
        uint8 enableInterrupts;

        enableInterrupts = CyEnterCriticalSection();
        /* Clear the HW FIFO */
        XB_TXDATA_AUX_CTL_REG |= (uint8)  XB_TX_FIFO_CLR;
        XB_TXDATA_AUX_CTL_REG &= (uint8) ~XB_TX_FIFO_CLR;
        CyExitCriticalSection(enableInterrupts);

    #if (XB_TX_INTERRUPT_ENABLED)

        /* Protect variables that could change on interrupt. */
        XB_DisableTxInt();

        XB_txBufferRead = 0u;
        XB_txBufferWrite = 0u;

        /* Enable Tx interrupt. */
        XB_EnableTxInt();

    #endif /* (XB_TX_INTERRUPT_ENABLED) */
    }


    /*******************************************************************************
    * Function Name: XB_SendBreak
    ********************************************************************************
    *
    * Summary:
    *  Transmits a break signal on the bus.
    *
    * Parameters:
    *  uint8 retMode:  Send Break return mode. See the following table for options.
    *   XB_SEND_BREAK - Initialize registers for break, send the Break
    *       signal and return immediately.
    *   XB_WAIT_FOR_COMPLETE_REINIT - Wait until break transmission is
    *       complete, reinitialize registers to normal transmission mode then return
    *   XB_REINIT - Reinitialize registers to normal transmission mode
    *       then return.
    *   XB_SEND_WAIT_REINIT - Performs both options: 
    *      XB_SEND_BREAK and XB_WAIT_FOR_COMPLETE_REINIT.
    *      This option is recommended for most cases.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  XB_initVar - checked to identify that the component has been
    *     initialized.
    *  txPeriod - static variable, used for keeping TX period configuration.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  SendBreak function initializes registers to send 13-bit break signal. It is
    *  important to return the registers configuration to normal for continue 8-bit
    *  operation.
    *  There are 3 variants for this API usage:
    *  1) SendBreak(3) - function will send the Break signal and take care on the
    *     configuration returning. Function will block CPU until transmission
    *     complete.
    *  2) User may want to use blocking time if UART configured to the low speed
    *     operation
    *     Example for this case:
    *     SendBreak(0);     - initialize Break signal transmission
    *         Add your code here to use CPU time
    *     SendBreak(1);     - complete Break operation
    *  3) Same to 2) but user may want to initialize and use the interrupt to
    *     complete break operation.
    *     Example for this case:
    *     Initialize TX interrupt with "TX - On TX Complete" parameter
    *     SendBreak(0);     - initialize Break signal transmission
    *         Add your code here to use CPU time
    *     When interrupt appear with XB_TX_STS_COMPLETE status:
    *     SendBreak(2);     - complete Break operation
    *
    * Side Effects:
    *  The XB_SendBreak() function initializes registers to send a
    *  break signal.
    *  Break signal length depends on the break signal bits configuration.
    *  The register configuration should be reinitialized before normal 8-bit
    *  communication can continue.
    *
    *******************************************************************************/
    void XB_SendBreak(uint8 retMode) 
    {

        /* If not Initialized then skip this function*/
        if(XB_initVar != 0u)
        {
            /* Set the Counter to 13-bits and transmit a 00 byte */
            /* When that is done then reset the counter value back */
            uint8 tmpStat;

        #if(XB_HD_ENABLED) /* Half Duplex mode*/

            if( (retMode == XB_SEND_BREAK) ||
                (retMode == XB_SEND_WAIT_REINIT ) )
            {
                /* CTRL_HD_SEND_BREAK - sends break bits in HD mode */
                XB_WriteControlRegister(XB_ReadControlRegister() |
                                                      XB_CTRL_HD_SEND_BREAK);
                /* Send zeros */
                XB_TXDATA_REG = 0u;

                do /* Wait until transmit starts */
                {
                    tmpStat = XB_TXSTATUS_REG;
                }
                while((tmpStat & XB_TX_STS_FIFO_EMPTY) != 0u);
            }

            if( (retMode == XB_WAIT_FOR_COMPLETE_REINIT) ||
                (retMode == XB_SEND_WAIT_REINIT) )
            {
                do /* Wait until transmit complete */
                {
                    tmpStat = XB_TXSTATUS_REG;
                }
                while(((uint8)~tmpStat & XB_TX_STS_COMPLETE) != 0u);
            }

            if( (retMode == XB_WAIT_FOR_COMPLETE_REINIT) ||
                (retMode == XB_REINIT) ||
                (retMode == XB_SEND_WAIT_REINIT) )
            {
                XB_WriteControlRegister(XB_ReadControlRegister() &
                                              (uint8)~XB_CTRL_HD_SEND_BREAK);
            }

        #else /* XB_HD_ENABLED Full Duplex mode */

            static uint8 txPeriod;

            if( (retMode == XB_SEND_BREAK) ||
                (retMode == XB_SEND_WAIT_REINIT) )
            {
                /* CTRL_HD_SEND_BREAK - skip to send parity bit at Break signal in Full Duplex mode */
                #if( (XB_PARITY_TYPE != XB__B_UART__NONE_REVB) || \
                                    (XB_PARITY_TYPE_SW != 0u) )
                    XB_WriteControlRegister(XB_ReadControlRegister() |
                                                          XB_CTRL_HD_SEND_BREAK);
                #endif /* End XB_PARITY_TYPE != XB__B_UART__NONE_REVB  */

                #if(XB_TXCLKGEN_DP)
                    txPeriod = XB_TXBITCLKTX_COMPLETE_REG;
                    XB_TXBITCLKTX_COMPLETE_REG = XB_TXBITCTR_BREAKBITS;
                #else
                    txPeriod = XB_TXBITCTR_PERIOD_REG;
                    XB_TXBITCTR_PERIOD_REG = XB_TXBITCTR_BREAKBITS8X;
                #endif /* End XB_TXCLKGEN_DP */

                /* Send zeros */
                XB_TXDATA_REG = 0u;

                do /* Wait until transmit starts */
                {
                    tmpStat = XB_TXSTATUS_REG;
                }
                while((tmpStat & XB_TX_STS_FIFO_EMPTY) != 0u);
            }

            if( (retMode == XB_WAIT_FOR_COMPLETE_REINIT) ||
                (retMode == XB_SEND_WAIT_REINIT) )
            {
                do /* Wait until transmit complete */
                {
                    tmpStat = XB_TXSTATUS_REG;
                }
                while(((uint8)~tmpStat & XB_TX_STS_COMPLETE) != 0u);
            }

            if( (retMode == XB_WAIT_FOR_COMPLETE_REINIT) ||
                (retMode == XB_REINIT) ||
                (retMode == XB_SEND_WAIT_REINIT) )
            {

            #if(XB_TXCLKGEN_DP)
                XB_TXBITCLKTX_COMPLETE_REG = txPeriod;
            #else
                XB_TXBITCTR_PERIOD_REG = txPeriod;
            #endif /* End XB_TXCLKGEN_DP */

            #if( (XB_PARITY_TYPE != XB__B_UART__NONE_REVB) || \
                 (XB_PARITY_TYPE_SW != 0u) )
                XB_WriteControlRegister(XB_ReadControlRegister() &
                                                      (uint8) ~XB_CTRL_HD_SEND_BREAK);
            #endif /* End XB_PARITY_TYPE != NONE */
            }
        #endif    /* End XB_HD_ENABLED */
        }
    }


    /*******************************************************************************
    * Function Name: XB_SetTxAddressMode
    ********************************************************************************
    *
    * Summary:
    *  Configures the transmitter to signal the next bytes is address or data.
    *
    * Parameters:
    *  addressMode: 
    *       XB_SET_SPACE - Configure the transmitter to send the next
    *                                    byte as a data.
    *       XB_SET_MARK  - Configure the transmitter to send the next
    *                                    byte as an address.
    *
    * Return:
    *  None.
    *
    * Side Effects:
    *  This function sets and clears XB_CTRL_MARK bit in the Control
    *  register.
    *
    *******************************************************************************/
    void XB_SetTxAddressMode(uint8 addressMode) 
    {
        /* Mark/Space sending enable */
        if(addressMode != 0u)
        {
        #if( XB_CONTROL_REG_REMOVED == 0u )
            XB_WriteControlRegister(XB_ReadControlRegister() |
                                                  XB_CTRL_MARK);
        #endif /* End XB_CONTROL_REG_REMOVED == 0u */
        }
        else
        {
        #if( XB_CONTROL_REG_REMOVED == 0u )
            XB_WriteControlRegister(XB_ReadControlRegister() &
                                                  (uint8) ~XB_CTRL_MARK);
        #endif /* End XB_CONTROL_REG_REMOVED == 0u */
        }
    }

#endif  /* EndXB_TX_ENABLED */

#if(XB_HD_ENABLED)


    /*******************************************************************************
    * Function Name: XB_LoadRxConfig
    ********************************************************************************
    *
    * Summary:
    *  Loads the receiver configuration in half duplex mode. After calling this
    *  function, the UART is ready to receive data.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    * Side Effects:
    *  Valid only in half duplex mode. You must make sure that the previous
    *  transaction is complete and it is safe to unload the transmitter
    *  configuration.
    *
    *******************************************************************************/
    void XB_LoadRxConfig(void) 
    {
        XB_WriteControlRegister(XB_ReadControlRegister() &
                                                (uint8)~XB_CTRL_HD_SEND);
        XB_RXBITCTR_PERIOD_REG = XB_HD_RXBITCTR_INIT;

    #if (XB_RX_INTERRUPT_ENABLED)
        /* Enable RX interrupt after set RX configuration */
        XB_SetRxInterruptMode(XB_INIT_RX_INTERRUPTS_MASK);
    #endif /* (XB_RX_INTERRUPT_ENABLED) */
    }


    /*******************************************************************************
    * Function Name: XB_LoadTxConfig
    ********************************************************************************
    *
    * Summary:
    *  Loads the transmitter configuration in half duplex mode. After calling this
    *  function, the UART is ready to transmit data.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    * Side Effects:
    *  Valid only in half duplex mode. You must make sure that the previous
    *  transaction is complete and it is safe to unload the receiver configuration.
    *
    *******************************************************************************/
    void XB_LoadTxConfig(void) 
    {
    #if (XB_RX_INTERRUPT_ENABLED)
        /* Disable RX interrupts before set TX configuration */
        XB_SetRxInterruptMode(0u);
    #endif /* (XB_RX_INTERRUPT_ENABLED) */

        XB_WriteControlRegister(XB_ReadControlRegister() | XB_CTRL_HD_SEND);
        XB_RXBITCTR_PERIOD_REG = XB_HD_TXBITCTR_INIT;
    }

#endif  /* XB_HD_ENABLED */


/* [] END OF FILE */
